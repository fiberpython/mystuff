<?php

if ( ! class_exists( 'cmb_Meta_Box' ) ) {
	require_once( dirname( __FILE__ ) . '/init.php' );
}
