<?php

class P2P_Exception extends RuntimeException {}
